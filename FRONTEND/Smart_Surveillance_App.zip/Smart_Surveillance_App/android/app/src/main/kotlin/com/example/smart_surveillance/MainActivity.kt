package com.example.smart_surveillance

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
