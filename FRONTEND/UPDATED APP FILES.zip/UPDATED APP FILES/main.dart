import 'package:flutter/material.dart';
import 'package:collection/collection.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Surveillance',
      theme: ThemeData(
        primarySwatch: Colors.orange,
      ),
      home: AuthenticationScreen(),
    );
  }
}

class AuthenticationScreen extends StatelessWidget {
  const AuthenticationScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Smart Surveillance'),
        actions: [
          IconButton(
            onPressed: () {
              // Navigate to the home screen
              Navigator.of(context).pushReplacement(MaterialPageRoute(
                builder: (context) => AuthenticationScreen(),
              ));
            },
            icon: const Icon(Icons.home),
          ),
          IconButton(
            onPressed: () {
              // Navigate to the login screen
              Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => LoginScreen(),
              ));
            },
            icon: const Icon(Icons.login),
          ),
          IconButton(
            onPressed: () {
              // Navigate to the signup screen
              Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => SignupScreen(),
              ));
            },
            icon: const Icon(Icons.person_add),
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text(
              'Smart Surveillance',
              style: TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.bold,
                color: Colors.orange,
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Navigate to the login screen
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => LoginScreen(),
                ));
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 32),
                textStyle: const TextStyle(fontSize: 18),
              ),
              child: const Text('Login'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Navigate to the signup screen
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => SignupScreen(),
                ));
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 32),
                textStyle: const TextStyle(fontSize: 18),
              ),
              child: const Text('Signup'),
            ),
          ],
        ),
      ),
    );
  }
}

class User {
  final String name;
  final String username;
  final String password;
  final String gender;
  final int age;
  final String email;
  final String contactNumber;
  final String vehicleType;
  final String model;
  final String color;
  final String registeredCity;
  final String licensePlate;
  final String profilePicture; // New field for the profile picture

  User({
    required this.name,
    required this.username,
    required this.password,
    required this.gender,
    required this.age,
    required this.email,
    required this.contactNumber,
    required this.vehicleType,
    required this.model,
    required this.color,
    required this.registeredCity,
    required this.licensePlate,
    required this.profilePicture, // Include the profile picture
  });
}

List<User> users = [
  User(
    name: 'John Doe',
    username: 'user1',
    password: 'password1',
    gender: 'Male',
    age: 30,
    email: 'john@example.com',
    contactNumber: '1234567890',
    vehicleType: 'SUV',
    model: 'Model X',
    color: 'Blue',
    registeredCity: 'New York',
    licensePlate: 'ABC123',
    profilePicture: 'johncena.jpg',

  ),
  User(
    name: 'Jane Smith',
    username: 'user2',
    password: 'password2',
    gender: 'Female',
    age: 28,
    email: 'jane@example.com',
    contactNumber: '9876543210',
    vehicleType: 'Sedan',
    model: 'Model Y',
    color: 'Red',
    registeredCity: 'Los Angeles',
    licensePlate: 'XYZ456',
    profilePicture: 'johnwick.jpg',
  ),
  // Add more users as needed
];

class LoginScreen extends StatelessWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final usernameController = TextEditingController();
    final passwordController = TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Login'),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => const SignupScreen(),
              ));
            },
            icon: const Icon(Icons.person_add), // Signup button
          ),
          IconButton(
            onPressed: () {
              Navigator.of(context).pushReplacement(MaterialPageRoute(
                builder: (context) => const AuthenticationScreen(),
              ));
            },
            icon: const Icon(Icons.home), // Home button
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const Text(
              'Login to Your Account',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            TextFormField(
              controller: usernameController,
              decoration: const InputDecoration(labelText: 'Username'),
            ),
            TextFormField(
              controller: passwordController,
              obscureText: true, // Hide the entered password
              decoration: const InputDecoration(labelText: 'Password'),
            ),
            ElevatedButton(
              onPressed: () {
                final enteredUsername = usernameController.text;
                final enteredPassword = passwordController.text;

                final user = users.firstWhereOrNull(
                      (user) =>
                  user.username == enteredUsername &&
                      user.password == enteredPassword,
                );

                if (user != null) {
                  // Navigate to the logged-in screen if credentials are correct
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (context) => LoggedInScreen(user: user),
                  ));
                } else {
                  // Show an error message for incorrect credentials
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Invalid username or password'),
                    ),
                  );
                }
              },
              child: const Text('Login'),
            ),
          ],
        ),
      ),
    );
  }
}

class SignupScreen extends StatefulWidget {
  const SignupScreen({Key? key}) : super(key: key);

  @override
  _SignupScreenState createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final nameController = TextEditingController();
  final usernameController = TextEditingController();
  final passwordController = TextEditingController();
  final reenterPasswordController = TextEditingController();
  final genderController = TextEditingController();
  final ageController = TextEditingController();
  final emailController = TextEditingController();
  final contactNumberController = TextEditingController();
  final vehicleTypeController = TextEditingController();
  final modelController = TextEditingController();
  final colorController = TextEditingController();
  final registeredCityController = TextEditingController();
  final licensePlateController = TextEditingController();
  XFile? _pickedImage; // Variable to store the picked image

  // Function to pick an image
  Future<void> _pickImage() async {
    final pickedImage = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedImage != null) {
      setState(() {
        _pickedImage = pickedImage;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Signup'),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.of(context).pushReplacement(MaterialPageRoute(
                builder: (context) => const AuthenticationScreen(),
              ));
            },
            icon: const Icon(Icons.home), // Home button
          ),
          IconButton(
            onPressed: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => const LoginScreen(),
              ));
            },
            icon: const Icon(Icons.login), // Login button
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const Text(
                'Create an Account',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              ElevatedButton(
                onPressed: _pickImage, // Call the _pickImage function
                child: const Text('Pick Profile Picture'),
              ),
              _pickedImage != null
                  ? Image.file(
                File(_pickedImage!.path),
                height: 100, // Adjust the height as needed
              )
                  : const SizedBox.shrink(),
              TextFormField(
                controller: nameController,
                decoration: const InputDecoration(labelText: 'Name'),
              ),
              TextFormField(
                controller: usernameController,
                decoration: const InputDecoration(labelText: 'Username'),
              ),
              TextFormField(
                controller: passwordController,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Password'),
              ),
              TextFormField(
                controller: reenterPasswordController,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Re-enter Password'),
              ),
              TextFormField(
                controller: genderController,
                decoration: const InputDecoration(labelText: 'Gender'),
              ),
              TextFormField(
                controller: ageController,
                decoration: const InputDecoration(labelText: 'Age'),
              ),
              TextFormField(
                controller: emailController,
                decoration: const InputDecoration(labelText: 'Email'),
              ),
              TextFormField(
                controller: contactNumberController,
                decoration: const InputDecoration(labelText: 'Contact Number'),
              ),
              TextFormField(
                controller: vehicleTypeController,
                decoration: const InputDecoration(labelText: 'Vehicle Type'),
              ),
              TextFormField(
                controller: modelController,
                decoration: const InputDecoration(labelText: 'Model'),
              ),
              TextFormField(
                controller: colorController,
                decoration: const InputDecoration(labelText: 'Color'),
              ),
              TextFormField(
                controller: registeredCityController,
                decoration: const InputDecoration(labelText: 'Registered City'),
              ),
              TextFormField(
                controller: licensePlateController,
                decoration: const InputDecoration(labelText: 'License Plate Number'),
              ),
              ElevatedButton(
                onPressed: () {
                  final name = nameController.text;
                  final username = usernameController.text;
                  final password = passwordController.text;
                  final reenteredPassword = reenterPasswordController.text;
                  final gender = genderController.text;
                  final age = int.tryParse(ageController.text) ?? 0;
                  final email = emailController.text;
                  final contactNumber = contactNumberController.text;
                  final vehicleType = vehicleTypeController.text;
                  final model = modelController.text;
                  final color = colorController.text;
                  final registeredCity = registeredCityController.text;
                  final licensePlate = licensePlateController.text;

                  if (password != reenteredPassword) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Passwords do not match'),
                      ),
                    );
                    return;
                  }

                  final profilePicture = _pickedImage?.path ?? ''; // Use the picked image path

                  final newUser = User(
                    name: name,
                    username: username,
                    password: password,
                    gender: gender,
                    age: age,
                    email: email,
                    contactNumber: contactNumber,
                    vehicleType: vehicleType,
                    model: model,
                    color: color,
                    registeredCity: registeredCity,
                    licensePlate: licensePlate,
                    profilePicture: profilePicture, // Include the profile picture path
                  );

                  // Add the new user to the list
                  users.add(newUser);

                  // Navigate to the logged-in screen for the new user
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (context) => LoggedInScreen(user: newUser),
                  ));
                },
                child: const Text('Signup'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}



class LoggedInScreen extends StatelessWidget {
  final User user;

  const LoggedInScreen({required this.user});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Logged In'),
        actions: [
          IconButton(
            onPressed: () {
              // Implement log out logic here
              Navigator.of(context).pushReplacement(MaterialPageRoute(
                builder: (context) => const SignedOutScreen(),
              ));
            },
            icon: const Icon(Icons.logout), // Sign out button
          ),
        ],
      ),
      body: ListView(
        children: <Widget>[
          const SizedBox(height: 20),
          Center(
            child: Text(
              'Welcome, ${user.username}!',
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 20),
          // Display the profile picture
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image.asset(
              user.profilePicture, // Assuming user.profilePicture contains the asset path
              width: 150, // Adjust the width as needed
              height: 150, // Adjust the height as needed
            ),
          ),
          ListTile(
            title: const Text('Name:'),
            subtitle: Text(user.name),
          ),
          ListTile(
            title: const Text('Username:'),
            subtitle: Text(user.username),
          ),
          ListTile(
            title: const Text('Gender:'),
            subtitle: Text(user.gender),
          ),
          ListTile(
            title: const Text('Age:'),
            subtitle: Text(user.age.toString()),
          ),
          ListTile(
            title: const Text('Email:'),
            subtitle: Text(user.email),
          ),
          ListTile(
            title: const Text('Contact Number:'),
            subtitle: Text(user.contactNumber),
          ),
          ListTile(
            title: const Text('Vehicle Type:'),
            subtitle: Text(user.vehicleType),
          ),
          ListTile(
            title: const Text('Model:'),
            subtitle: Text(user.model),
          ),
          ListTile(
            title: const Text('Color:'),
            subtitle: Text(user.color),
          ),
          ListTile(
            title: const Text('Registered City:'),
            subtitle: Text(user.registeredCity),
          ),
          ListTile(
            title: const Text('License Plate Number:'),
            subtitle: Text(user.licensePlate),
          ),
        ],
      ),
    );
  }
}

class SignedOutScreen extends StatelessWidget {
  const SignedOutScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Signed Out'),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.of(context).pushReplacement(MaterialPageRoute(
                builder: (context) => const AuthenticationScreen(),
              ));
            },
            icon: const Icon(Icons.home), // Home button
          ),
          IconButton(
            onPressed: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => const LoginScreen(),
              ));
            },
            icon: const Icon(Icons.login), // Login button
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text(
              'User has signed out',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            ElevatedButton(
              onPressed: () {
                // Navigate to the home screen
                Navigator.of(context).pushReplacement(MaterialPageRoute(
                  builder: (context) => const AuthenticationScreen(),
                ));
              },
              child: const Text('Home'),
            ),
            ElevatedButton(
              onPressed: () {
                // Navigate to the login screen
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => const LoginScreen(),
                ));
              },
              child: const Text('Login'),
            ),
          ],
        ),
      ),
    );
  }
}
